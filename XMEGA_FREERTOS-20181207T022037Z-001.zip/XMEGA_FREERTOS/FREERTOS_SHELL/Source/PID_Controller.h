//**********************************************************************************
/** \file PID_controller.h
 *    This file contains a highly configurable PI control algorithm.
 *
 *  \author 
 *
 *  Revisions:
 *	  \li 12-02-2018
 *
 *  License:
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */


// This define prevents this .h file from being included multiple times in a .CPP file
#ifndef PID_CONTROLLER_H_
#define PID_CONTROLLER_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include "satmath.h"

//**********************************************************************************
/** \brief This class defines and runs a 16-bit fixed point PID controller
 */
class PID_Controller
{
	public:
	/** \brief This enumeration defines possible modes of operation for the PID controller.
	 */
	typedef enum PID_MODE {
		OFF					= 1,						//!< Controller is disabled
		MANUAL				= 2,						//!< Controller is in manual mode
		P					= 3,						//!< P mode only
		PI					= 4,						//!< PI mode only
		PD					= 5,						//!< PD mode only
		PID					= 6							//!< PID mode only
	} PID_MODE_t;

	/** \brief this struct defines a pid configuration that contains all the tuning parameters for
	 */
	typedef struct PID_config {
		int32_t				Kp = 0;						//!< Proportional gain
		int32_t				Gain_divider = 1;			//!< Gain divider for higher resolution
		int32_t				Kaw = 0;					//!< Anti-windup gain	
		int32_t				Ki = 0;						//!< Integral gain
		int32_t				Int_sat_max = INT16_MAX;	//!< Max integral signal saturation
		int32_t				Int_sat_min	= INT16_MIN;	//!< Min integral signal saturation
		int32_t				Kd = 0;						//!< Derivative gain 
		int32_t				act_sat_max = 1600;			//!< Max actuation signal saturation
		int32_t				act_sat_min = -1600;		//!< Min actuation signal saturation
	} PID_config_t;
	
	// Constructors
	PID_Controller();									//!< PID Default constructor
	PID_Controller(PID_config_t cfg);					//!< Configuration Constructor
	
	// Methods
	int16_t					run();						//!< Method for running the control loop one iteration
	
	// Attributes
	PID_MODE_t				mode = PID;					//!< PID Mode enumeration
	PID_config_t			cfg;						//!< PID configuration struct
	int32_t					reference_value = 0;		//!< Pointer to Set point for controller
	int32_t					actual_reading = 0;			//!< Pointer to actual or measured value being controlled
	int32_t					act_output = 0;				//!< 
	int32_t					act_sig_pre_sat = 0;		//!< Total actuator signal pre-saturation
	int32_t					error = 0;					//!< Error between reference and actual values



	
	protected:
	//int32_t					error = 0;					//!< Error between reference and actual values
	int32_t					Kp_signal = 0;				//!< Proportional gain actuator signal
	int32_t					anti_windup_error = 0;		//!< Integral control anti windup error
	//int32_t					act_sig_pre_sat = 0;		//!< Total actuator signal pre-saturation
	int32_t					Ki_Kaw_error = 0;			//!< Integral and anti-windup error signal
	int32_t					Ki_signal = 0;				//!< Integral control actuator signal
	int32_t					previous_error = 0;			//!< Previous error 
	int32_t					Kd_signal = 0;				//!< Derivative control actuation signal
	
	private:
};


#endif /* PID_CONTROLLER_H_ */