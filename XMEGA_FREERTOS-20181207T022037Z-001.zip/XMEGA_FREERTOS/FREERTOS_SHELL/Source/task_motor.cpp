//**************************************************************************************
/** \file task_LED.cpp
 *    This file contains source code for a user interface task for a ME405/FreeRTOS
 *    test suite. 
 *
 *  Revisions:
 *    \li 09-16-2018 CTR Adapted from JRR task_user.cpp
 *    \li 09-30-2012 JRR Original file was a one-file demonstration with two tasks
 *    \li 10-05-2012 JRR Split into multiple files, one for each task
 *    \li 10-25-2012 JRR Changed to a more fully C++ version with class task_user
 *    \li 11-04-2012 JRR Modified from the data acquisition example to the test suite
 *
 *  License:
 *    This file is copyright 2012 by JR Ridgely and released under the Lesser GNU 
 *    Public License, version 2. It intended for educational use only, but its use
 *    is not limited thereto. */
/*    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */
//**************************************************************************************

#include <avr/io.h>                         // Port I/O for SFR's
#include <avr/wdt.h>                        // Watchdog timer header

#include "shared_data_sender.h"
#include "shared_data_receiver.h"
#include "task_motor.h"                      // Header for this file
#include "PID_Controller.h"

//-------------------------------------------------------------------------------------
/** This constructor creates a new data acquisition task. Its main job is to call the
 *  parent class's constructor which does most of the work.
 *  @param a_name A character string which will be the name of this task
 *  @param a_priority The priority at which this task will initially run (default: 0)
 *  @param a_stack_size The size of this task's stack in bytes 
 *                      (default: configMINIMAL_STACK_SIZE)
 *  @param p_ser_dev Pointer to a serial device (port, radio, SD card, etc.) which can
 *                   be used by this task to communicate (default: NULL)
 */

task_motor::task_motor (const char* a_name, 
					  unsigned portBASE_TYPE a_priority, 
					  size_t a_stack_size,
					  emstream* p_ser_dev,
					  uint8_t new_motor, // 1, 4, 2, or 3...
					  PID_Controller::PID_config_t pid_cfg
					 )
	: frt_task (a_name, a_priority, a_stack_size, p_ser_dev)
{
	mot_num = new_motor;
	mot_controller = PID_Controller(pid_cfg);
}

void task_motor::pwm_init()
{
	switch (mot_num)
	{
		case 1:
			PORTC.DIRSET = PIN2_bm | PIN3_bm;          //Set PC.0 as the output port
			TCC0.PER = 1600;            //Set the period of the waveform
			TCC0.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			TCC0.CTRLB |= TC0_CCCEN_bm | TC0_CCDEN_bm;   //channel selection CCAEN
			TCC0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			break;
		case 2:
			PORTD.DIRSET = PIN0_bm | PIN1_bm;    //Set PC.0 as the output port
			TCD0.PER = 1600;            //Set the period of the waveform
			TCD0.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			TCD0.CTRLB |= TC0_CCAEN_bm | TC0_CCBEN_bm;   //channel selection CCAEN
			TCD0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			//PORTD.OUTCLR = PIN0_bm | PIN1_bm;
			//TCD0.CCA = 0;
			//TCD0.CCB = 0;
			break;
		case 3:
			PORTD.DIRSET = PIN2_bm | PIN3_bm;          //Set PC.0 as the output port
			TCD1.PER = 1600;            //Set the period of the waveform
			TCD1.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			TCD1.CTRLB |= TC1_CCAEN_bm | TC1_CCBEN_bm;   //channel selection CCAEN
			TCD1.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			break;
		case 4:
			PORTC.DIRSET = PIN4_bm | PIN5_bm;          //Set PC.0 as the output port
			TCC1.PER = 1600;            //Set the period of the waveform
			TCC1.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			TCC1.CTRLB |= TC1_CCAEN_bm | TC1_CCBEN_bm;   //channel selection CCAEN
			TCC1.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			break;
	}
	
}
void task_motor::pwm_update(int16_t pwm_input)
{
	switch(mot_num)
	{
		case 1:
			if (pwm_input>0)
			{
				TCC0.CCCBUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				TCC0.CCDBUF = pwm_input;
			}
			else if (pwm_input<0)
			{
				pwm_input *= -1;
				TCC0.CCCBUF = pwm_input;
				TCC0.CCDBUF = 0;
			}
			else
			{
				TCC0.CCCBUF = 0;
				TCC0.CCDBUF = 0;
			}
			while((TCC0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			TCC0.INTFLAGS = 0x00;                   //clear the interrupt flag
			break;
		case 2:
			if (pwm_input>0)
			{
				TCD0.CCABUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				TCD0.CCBBUF = pwm_input;
			}
			else if (pwm_input<0)
			{
				pwm_input *= -1;
				TCD0.CCABUF = pwm_input;
				TCD0.CCBBUF = 0;
			}
			else
			{
				TCD0.CCABUF = 0;
				TCD0.CCBBUF = 0;
			}
			while((TCD0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			TCD0.INTFLAGS = 0x00;                   //clear the interrupt flag
			break;
		case 3:
			if (pwm_input>0)
			{
				TCD1.CCABUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				TCD1.CCBBUF = pwm_input;
			}
			else if (pwm_input<0)
			{
				pwm_input *= -1;
				TCD1.CCABUF = pwm_input;
				TCD1.CCBBUF = 0;
			}
			else
			{
				TCD1.CCABUF = 0;
				TCD1.CCBBUF = 0;
			}
			while((TCD1.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			TCD1.INTFLAGS = 0x00;                   //clear the interrupt flag
			break;
		case 4:
			if (pwm_input>0)
			{
				TCC1.CCABUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				TCC1.CCBBUF = pwm_input;
			}
			else if (pwm_input<0)
			{
				pwm_input *= -1;
				TCC1.CCABUF = pwm_input;
				TCC1.CCBBUF = 0;
			}
			else
			{
				TCC1.CCABUF = 0;
				TCC1.CCBBUF = 0;
			}
			while((TCC1.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			TCC1.INTFLAGS = 0x00;                   //clear the interrupt flag
			break;
	}
	
}
void task_motor::enc_init()
{
	switch( mot_num )
	{
		case 1:
			PORTB.DIRCLR = PIN0_bm | PIN1_bm;							// Set both CHa and CHb for input (resets them to zero)
			PORTB.PIN0CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			PORTB.PIN1CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			EVSYS.CH0MUX = EVSYS_CHMUX_PORTB_PIN0_gc;					// Configure CHa as a multiplexer input for event channel 0
			EVSYS.CH0CTRL = EVSYS_QDEN_bm | EVSYS_DIGFILT_2SAMPLES_gc;	// Enable the quadrature decoder
			TCF0.CTRLD = TC_EVACT_QDEC_gc | TC_EVSEL_CH0_gc;			// Set the quadrature decoding as the event action for the timer
			TCF0.PER = 0xFFFF;											// Set the timer counter period to max
			TCF0.CTRLA = TC_CLKSEL_DIV1_gc;								// Start the timer
			break;
		case 2:
			PORTB.DIRCLR = PIN2_bm | PIN3_bm;							// Set both CHa and CHb for input (resets them to zero)
			PORTB.PIN2CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			PORTB.PIN3CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			EVSYS.CH2MUX = EVSYS_CHMUX_PORTB_PIN2_gc;					// Configure CHa as a multiplexer input for event channel 0
			EVSYS.CH2CTRL = EVSYS_QDEN_bm | EVSYS_DIGFILT_2SAMPLES_gc;	// Enable the quadrature decoder
			TCE0.CTRLD = TC_EVACT_QDEC_gc | TC_EVSEL_CH2_gc;			// Set the quadrature decoding as the event action for the timer
			TCE0.PER = 0xFFFF;											// Set the timer counter period to max
			TCE0.CTRLA = TC_CLKSEL_DIV1_gc;								// Start the timer
			break;
		case 3:
			PORTB.DIRCLR = PIN4_bm | PIN5_bm;							// Set both CHa and CHb for input (resets them to zero)
			PORTB.PIN4CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			PORTB.PIN5CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			EVSYS.CH4MUX = EVSYS_CHMUX_PORTB_PIN4_gc;					// Configure CHa as a multiplexer input for event channel 0
			EVSYS.CH4CTRL = EVSYS_QDEN_bm | EVSYS_DIGFILT_2SAMPLES_gc;	// Enable the quadrature decoder
			//TCD1.CTRLD = TC_EVACT_QDEC_gc | TC_EVSEL_CH4_gc;			// Set the quadrature decoding as the event action for the timer
			//TCD1.PER = 0xFFFF;											// Set the timer counter period to max
			//TCD1.CTRLA = TC_CLKSEL_DIV1_gc;								// Start the timer
			TCC1.CTRLD = TC_EVACT_QDEC_gc | TC_EVSEL_CH4_gc;			// Set the quadrature decoding as the event action for the timer
			TCC1.PER = 0xFFFF;											// Set the timer counter period to max
			TCC1.CTRLA = TC_CLKSEL_DIV1_gc;								// Start the timer
			break;
		case 4:
			PORTB.DIRCLR = PIN6_bm | PIN7_bm;							// Set both CHa and CHb for input (resets them to zero)
			PORTB.PIN6CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			PORTB.PIN7CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			EVSYS.CH6MUX = EVSYS_CHMUX_PORTB_PIN6_gc;					// Configure CHa as a multiplexer input for event channel 0
			EVSYS.CH6CTRL = EVSYS_QDEN_bm | EVSYS_DIGFILT_2SAMPLES_gc;	// Enable the quadrature decoder
			TCC0.CTRLD = TC_EVACT_QDEC_gc | TC_EVSEL_CH6_gc;			// Set the quadrature decoding as the event action for the timer
			TCC0.PER = 0xFFFF;											// Set the timer counter period to max
			TCC0.CTRLA = TC_CLKSEL_DIV1_gc;								// Start the timer
			break;
	}
}
// USED BY MASTER:
void task_motor::set_encoderRef(int32_t new_encoderRef)
{
	encoderRef = new_encoderRef;
}

//-------------------------------------------------------------------------------------
/** This task blinks an LED attached to PORTR Pin 1
 */

void task_motor::run (void)
{
	// Make a variable which will hold times to use for precise task scheduling
	portTickType previousTicks = xTaskGetTickCount ();

	// Wait a little while for user interface task to finish up
	delay_ms(10);
	
	int16_t prevCNT		= 0;
	int16_t nowCNT		= 0;
	int32_t deltaCNT	= 0;
	encoderCNT = 0;

	while(1)
	{
		switch (state)
		{
			case PWM_INIT:
				// ctr=0;
				pwm_input = 0;
				enc_init();
				pwm_init();
				transition_to(PWM_UPDATE);
				break;
				//
			//case WAIT:
				//if (update) transition_to(PWM_UPDATE);
				//break;
			case PWM_UPDATE:
				prevCNT = nowCNT;
				switch (mot_num)
				{
					case 1:
						nowCNT = TCF0.CNT;
						break;
					case 2:
						nowCNT = TCE0.CNT;
						break;
					case 3:
						nowCNT = TCC1.CNT;
						break;
					case 4:
						nowCNT = TCC0.CNT;
						break;
				}
				deltaCNT = int32_t(nowCNT - prevCNT); // type-casting is probably not necessary here, but whatevs brah
				encoderCNT += deltaCNT;
				mot_controller.actual_reading = encoderCNT;
				mot_controller.reference_value = encoderRef;
				pwm_input = mot_controller.run();
				pwm_update(pwm_input);
				//update = false;
				//transition_to(WAIT);
				break;
		
			default:
				break;
		}
		runs++;
		delay_from_to_ms(previousTicks,100);
	}
}