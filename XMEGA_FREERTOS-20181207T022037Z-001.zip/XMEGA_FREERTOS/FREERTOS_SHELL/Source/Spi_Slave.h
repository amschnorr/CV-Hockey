/*
 * SPI_Slave.h
 *
 * Created: 1/26/2018 10:17:12 AM
 *  Author: aschnorr, modified from crefvem
 */


#ifndef SPI_Slave_H_
#define SPI_Slave_H_

#include <avr/io.h>

typedef union SPI_packet
{
	uint8_t buffer[2];
	uint16_t data;
} SPI_packet_t;

class SPI_Slave
{
	private:

	protected:
	SPI_t* interface;

	public:
	SPI_Slave(SPI_t* interface);
	void set_mode(int8_t SPI_mode);
	void start_transaction();
	void end_transaction();
	int8_t send_and_receive(int8_t len, int8_t* out_data, int8_t* in_data, int16_t timeout=1000);
};


#endif /* SPI_SLAVE_H_ */