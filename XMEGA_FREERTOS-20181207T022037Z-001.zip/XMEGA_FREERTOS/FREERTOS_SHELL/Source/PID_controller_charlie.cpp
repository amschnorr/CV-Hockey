//**********************************************************************************
/** \file PID_controller.cpp
 *    This file contains a highly configurable PI control algorithm.
 *
 *  \author Charlie Refvem
 *
 *  Revisions:
 *	  \li 11-17-2017 CTR Original File
 *
 *  License:
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */
//**********************************************************************************


#include "PID_controller.h"

//**********************************************************************************
/** \brief This constructor sets up an unconfigured 16 bit PID controller
 *  \details The PID is initialized with all gains set to 0 and no saturation limits.
 *           The pointers for actual, reference, feedforward, and feedback values
 *           are set as nullptrs by default.
 */
PID_Controller::PID_Controller()
{
	
}

//**********************************************************************************
/** \brief This constructor sets up a configured 16 bit PID controller
 *  \details The PID is initialized with a configuration as defined by the input
 *           to the constructor.
 *  @param cfg A struct containing the desired configuration parameters for the PID.
 */
PID_Controller::PID_Controller(PID_config_t cfg):cfg(cfg)
{
	
}

//**********************************************************************************
/** \brief Computes the new PID output value
 *  \details This method uses current actual and reference values to compute the controller
 *           output value. The mode and gain settings are considered during the calculation
 *  @return This function returns the new output of the PID controller after updating the state
 *          of the controller.
 */
int16_t PID_Controller::run()
{
	// exit immediately with effort = 0 if controller in off mode
	if(mode == OFF)
	{
		return 0;
	}
	
	// Compute error
	error = sssub(reference,actual);
	
	// Compute proportional actuation signal
	if(mode == PI || mode == P) 
	{
		a_p = ssdiv(ssmul(cfg.Kp,error),256);
	}
	else if(mode == IP)
	{
		a_p = ssdiv(ssmul(cfg.Kp,actual),256);
	}
	else
	{
		a_p = 0;
	}
	
	// Compute integral accounting for windup
	int16_t antiwindup = ssdiv(ssmul(cfg.Kw,sssub(a_desired,a_requested)),256);
	int16_t adj_error = sssub(error,antiwindup);
	//esum = ssadd(esum,adj_error);
	//a_i = ssdiv(ssmul(cfg.Ki,esum),256);
	esum += ssmul(cfg.Ki,adj_error);
	if (esum > 0x40000000)
	{
		esum = 0x40000000;
	}
	else if (esum < -(0x40000000))
	{
		esum = -(0x40000000);
	}
	// Compute integral actuation signal
	a_i = ssdiv(esum,256);
	
	// Compute feed forward actuation signal
	a_ff = ssdiv(ssmul(cfg.Kff,feedforward),256);
	
	// compute feedback actuation signal
	a_fb = ssdiv(ssmul(cfg.Kfb,feedback),256);
	
	// Combine actuation signals
	if (mode == PI || mode == IP)
	{
		a_desired = ssadd(a_i,a_p);	
	}
	else
	{
		a_desired = a_p;
	}
	a_desired = ssadd(a_desired,a_ff);
	a_desired = ssadd(a_desired,a_fb);
	
	// Saturate the desired value to come up with a requested value
	if (a_desired >= cfg.sat_max)
	{
		a_requested = cfg.sat_max;
	}
	else if (a_desired <= cfg.sat_min)
	{
		a_requested = cfg.sat_min;
	}
	else
	{
		a_requested = a_desired;
	}
	
	// Finally multiply by amplifier gain to produce the output
	a_output = ssdiv(ssmul(cfg.Ka, a_requested),256);

	return a_output;
}