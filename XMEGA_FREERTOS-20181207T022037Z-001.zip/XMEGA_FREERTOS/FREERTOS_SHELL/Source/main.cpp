//*************************************************************************************
/** \file lab1_main.cpp
 *    This file contains the main() code for a program which runs a port of the FreeRTOS
 *    for AVR devices. This port is specific to the XMEGA family.
 *
 *  Revisions:
 *    \li 09-14-2017 CTR Adapted from JRR code for AVR to be compatible with xmega 
 *
 *  License:
 *    This file is released under the Lesser GNU Public License, version 2. This 
 *    program is intended for educational use only, but it is not limited thereto. 
 */
//*************************************************************************************


#include <stdlib.h>                         // Prototype declarations for I/O functions
#include <avr/io.h>                         // Port I/O for SFR's
#include <avr/wdt.h>                        // Watchdog timer header
#include <avr/interrupt.h>
#include <string.h>                         // Functions for C string handling

#include <util/delay.h>

//Charlie code_______
#include "satmath.h"
//___________________

#include "FreeRTOS.h"                       // Primary header for FreeRTOS
#include "task.h"                           // Header for FreeRTOS task functions
#include "queue.h"                          // FreeRTOS inter-task communication queues
#include "croutine.h"                       // Header for co-routines and such

#include "rs232int.h"                       // ME405/507 library for serial comm.
#include "time_stamp.h"                     // Class to implement a microsecond timer
#include "frt_task.h"                       // Header of wrapper for FreeRTOS tasks
#include "frt_text_queue.h"                 // Wrapper for FreeRTOS character queues
#include "frt_queue.h"                      // Header of wrapper for FreeRTOS queues
#include "frt_shared_data.h"                // Header for thread-safe shared data
#include "shares.h"                         // Global ('extern') queue declarations

#include "xmega_util.h"

#include "task_user.h"                      // Header for user interface task
//#include "task_LED.h"                       // Header for user interface task

#include "rs232int.h"						// Header for rs232
#include "PID_Controller.h"
#include "task_motor.h"
#include "task_master.h"
#include "task_IO.h"
#include "task_vision.h"

#include "SPI_Slave.h"                      // SPI oh yeah!

rs232 ser_dev(0,&USARTE0); // Create a serial device on USART E0
SPI_Slave spi_d = SPI_Slave(&SPID); //setup spi-slave mode

//uint16_t varname(3); //interesting



frt_text_queue print_ser_queue (32, NULL, 10);
//
//void pwm_init(int8_t mot_num)
//{
	//switch (mot_num)
	//{
		//case 1:
			//PORTC.DIRSET = PIN2_bm | PIN3_bm;          //Set PC.0 as the output port
			//TCC0.PER = 1600;            //Set the period of the waveform
			//TCC0.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			//TCC0.CTRLB |= TC0_CCCEN_bm | TC0_CCDEN_bm;   //channel selection CCAEN
			//TCC0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			//break;
		//case 2:
			//PORTD.DIRSET = PIN0_bm | PIN1_bm;    //Set PC.0 as the output port
			//TCD0.PER = 1600;            //Set the period of the waveform
			//TCD0.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			//TCD0.CTRLB |= TC0_CCAEN_bm | TC0_CCBEN_bm;   //channel selection CCAEN
			//TCD0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			//break;
		//case 3:
			//PORTD.DIRSET = PIN2_bm | PIN3_bm;          //Set PC.0 as the output port
			//TCD0.PER = 1600;            //Set the period of the waveform
			//TCD0.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			//TCD0.CTRLB |= TC0_CCCEN_bm | TC0_CCDEN_bm;   //channel selection CCAEN
			//TCD0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			//break;
		//case 4:
			//PORTC.DIRSET = PIN4_bm | PIN5_bm;          //Set PC.0 as the output port
			//TCC1.PER = 1600;            //Set the period of the waveform
			//TCC1.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
			//TCC1.CTRLB |= TC1_CCAEN_bm | TC1_CCBEN_bm;   //channel selection CCAEN
			//TCC1.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
			//break;
	//}
	//
//}
//void pwm_set(int8_t mot_num, int16_t pwm_input)
//{
	//switch(mot_num)
	//{
		//case 1:
			//if (pwm_input>0)
			//{
				//TCC0.CCCBUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				//TCC0.CCDBUF = pwm_input;
			//}
			//else if (pwm_input<0)
			//{
				//pwm_input *= -1;
				//TCC0.CCCBUF = pwm_input;
				//TCC0.CCDBUF = 0;
			//}
			//else
			//{
				//TCC0.CCCBUF = 0;
				//TCC0.CCDBUF = 0;
			//}
			//while((TCC0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			//TCC0.INTFLAGS = 0x00;                   //clear the interrupt flag
			//break;
		//case 2:
			//if (pwm_input>0)
			//{
				//TCD0.CCABUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				//TCD0.CCBBUF = pwm_input;
			//}
			//else if (pwm_input<0)
			//{
				//pwm_input *= -1;
				//TCD0.CCABUF = pwm_input;
				//TCD0.CCBBUF = 0;
			//}
			//else
			//{
				//TCD0.CCABUF = 0;
				//TCD0.CCBBUF = 0;
			//}
			//while((TCD0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			//TCD0.INTFLAGS = 0x00;                   //clear the interrupt flag
			//break;
		//case 3:
			//if (pwm_input>0)
			//{
				//TCD0.CCCBUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				//TCD0.CCDBUF = pwm_input;
			//}
			//else if (pwm_input<0)
			//{
				//pwm_input *= -1;
				//TCD0.CCCBUF = pwm_input;
				//TCD0.CCDBUF = 0;
			//}
			//else
			//{
				//TCD0.CCCBUF = 0;
				//TCD0.CCDBUF = 0;
			//}
			//while((TCD0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			//TCD0.INTFLAGS = 0x00;                   //clear the interrupt flag
			//break;
		//case 4:
			//if (pwm_input>0)
			//{
				//TCC1.CCABUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
				//TCC1.CCBBUF = pwm_input;
			//}
			//else if (pwm_input<0)
			//{
				//pwm_input *= -1;
				//TCC1.CCABUF = pwm_input;
				//TCC1.CCBBUF = 0;
			//}
			//else
			//{
				//TCC1.CCABUF = 0;
				//TCC1.CCBBUF = 0;
			//}
			//while((TCC1.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
			//TCC1.INTFLAGS = 0x00;                   //clear the interrupt flag
			//break;
	//}
	//
//}
//void pwm_init1(void)
//{
	//PORTC.DIRSET = PIN2_bm | PIN3_bm;          //Set PC.0 as the output port
	//TCC0.PER = 1600;            //Set the period of the waveform
	//TCC0.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
	//TCC0.CTRLB |= TC0_CCCEN_bm | TC0_CCDEN_bm;   //channel selection CCAEN
	//TCC0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk
//}
//void pwm_set1(int16_t pwm_input)
//{
	//if (pwm_input>0)
	//{
		//TCC0.CCCBUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
		//TCC0.CCDBUF = pwm_input;
	//}
	//else if (pwm_input<0)
	//{
		//pwm_input *= -1;
		//TCC0.CCCBUF = pwm_input;
		//TCC0.CCDBUF = 0;
	//}
	//else
	//{
		//TCC0.CCCBUF = 0;
		//TCC0.CCDBUF = 0;
	//}
	//while((TCC0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
	//TCC0.INTFLAGS = 0x00;                   //clear the interrupt flag
//}
//void pwm_init4(void)
//{
	//PORTC.DIRSET = PIN4_bm | PIN5_bm;          //Set PC.0 as the output port
	//TCC1.PER = 1600;            //Set the period of the waveform
	//TCC1.CTRLB |= 0x03;           //Single slope mode //TC_WGMODE_SS_gc
	//TCC1.CTRLB |= TC1_CCAEN_bm | TC1_CCBEN_bm;   //channel selection CCAEN
	//TCC1.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
//}
//void pwm_set4(int16_t pwm_input)
//{
	//if (pwm_input>0)
	//{
		//TCC1.CCABUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
		//TCC1.CCBBUF = pwm_input;
	//}
	//else if (pwm_input<0)
	//{
		//pwm_input *= -1;
		//TCC1.CCABUF = pwm_input;
		//TCC1.CCBBUF = 0;
	//}
	//else
	//{
		//TCC1.CCABUF = 0;
		//TCC1.CCBBUF = 0;
	//}
	//while((TCC1.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
	//TCC1.INTFLAGS = 0x00;                   //clear the interrupt flag
//}
//void pwm_init2(void)
//{
	//PORTD.DIRSET = PIN0_bm | PIN1_bm;    //Set PC.0 as the output port
	////PORTD.OUTSET = PIN0_bm | PIN1_bm;          
	//TCD0.PER = 1600;            //Set the period of the waveform
	//TCD0.CTRLB |= 0x03;           //Single slope mode //TC_WGMODE_SS_gc
	//TCD0.CTRLB |= TC0_CCAEN_bm | TC0_CCBEN_bm;   //channel selection CCAEN
	//TCD0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
//}
//void pwm_set2(int16_t pwm_input)
//{
	//if (pwm_input>0)
	//{
		//TCD0.CCABUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
		//TCD0.CCBBUF = pwm_input;
	//}
	//else if (pwm_input<0)
	//{
		//pwm_input *= -1;
		//TCD0.CCABUF = pwm_input;
		//TCD0.CCBBUF = 0;
	//}
	//else
	//{
		//TCD0.CCABUF = 0;
		//TCD0.CCBBUF = 0;
	//}
	//while((TCD0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
	//TCD0.INTFLAGS = 0x00;                   //clear the interrupt flag
//}
//void pwm_init3(void)
//{
	//PORTD.DIRSET = PIN2_bm | PIN3_bm;          //Set PC.0 as the output port
	////PORTD.OUTSET = PIN2_bm | PIN3_bm;
	//TCD0.PER = 1600;            //Set the period of the waveform
	//TCD0.CTRLB |= TC_WGMODE_SS_gc;           //Single slope mode //TC_WGMODE_SS_gc
	//TCD0.CTRLB |= TC0_CCCEN_bm | TC0_CCDEN_bm;   //channel selection CCAEN
	//TCD0.CTRLA |= TC_CLKSEL_DIV1_gc;           //clock selection clk/2
//}
//void pwm_set3(int16_t pwm_input)
//{
	//if (pwm_input>0)
	//{
		//TCD0.CCCBUF = 0;                //Example: 0x7FFF sets the duty cycle as 50%
		//TCD0.CCDBUF = pwm_input;
	//}
	//else if (pwm_input<0)
	//{
		//pwm_input *= -1;
		//TCD0.CCCBUF = pwm_input;
		//TCD0.CCDBUF = 0;
	//}
	//else
	//{
		//TCD0.CCCBUF = 0;
		//TCD0.CCDBUF = 0;
	//}
	//while((TCD0.INTFLAGS & 0x01) == 0);     //wait for the new compare value to be loaded
	//TCD0.INTFLAGS = 0x00;                   //clear the interrupt flag
//}
//
//void enc_init(TC1_struct* timer_ptr, uint8_t pinA)
//{
	//switch( pinA )
	//{
		//case 0:
			//PORTB.DIRCLR = PIN0_bm | PIN1_bm;							// Set both CHa and CHb for input (resets them to zero)
			//PORTB.PIN0CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			//PORTB.PIN1CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			//EVSYS.CH0MUX = EVSYS_CHMUX_PORTB_PIN0_gc;					// Configure CHa as a multiplexer input for event channel 0
			//break;
		//case 2:
			//PORTB.DIRCLR = PIN2_bm | PIN3_bm;							// Set both CHa and CHb for input (resets them to zero)
			//PORTB.PIN2CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			//PORTB.PIN3CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			//EVSYS.CH0MUX = EVSYS_CHMUX_PORTB_PIN2_gc;					// Configure CHa as a multiplexer input for event channel 0
			//break;
		//case 4:
			//PORTB.DIRCLR = PIN4_bm | PIN5_bm;							// Set both CHa and CHb for input (resets them to zero)
			//PORTB.PIN4CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			//PORTB.PIN5CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			//EVSYS.CH0MUX = EVSYS_CHMUX_PORTB_PIN4_gc;					// Configure CHa as a multiplexer input for event channel 0
			//break;
		//case 6:
			//PORTB.DIRCLR = PIN6_bm | PIN7_bm;							// Set both CHa and CHb for input (resets them to zero)
			//PORTB.PIN6CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHa
			//PORTB.PIN7CTRL |= PORT_ISC_LEVEL_gc;						// Set low level sense for CHb
			//EVSYS.CH0MUX = EVSYS_CHMUX_PORTB_PIN6_gc;					// Configure CHa as a multiplexer input for event channel 0
			//break;
	//}
	//
	//EVSYS.CH0CTRL = EVSYS_QDEN_bm | EVSYS_DIGFILT_2SAMPLES_gc;	// Enable the quadrature decoder
	//
	//timer_ptr->CTRLD = TC_EVACT_QDEC_gc | TC_EVSEL_CH0_gc;			// Set the quadrature decoding as the event action for the timer
	//timer_ptr->PER = 0xFFFF;											// Set the timer counter period to max
	//timer_ptr->CTRLA = TC_CLKSEL_DIV1_gc;								// Start the timer
//}
//
////	CONTROL VARIABLES INIT______________________
uint16_t sampletime = F_CPU/500; // 64,000 clk cycles = 2 ms sample time
//int16_t prevCNT		= 0;
//int16_t nowCNT		= 0;
//int32_t deltaCNT	= 0;
//int32_t encoderCNT	= 0;
//int32_t encRef		= 0;
//int32_t prevError   = 0;
//int32_t nowError	= 0;
//int32_t deltaError  = 0;
//int32_t actSignal	= 0;
//int32_t proSignal	= 0;
//int32_t intSignal	= 0;
//int32_t derSignal	= 0;
//int32_t intError	= 0;
//int32_t derError	= 0;
//	PID GAINS___________________________________
//int32_t Kp =   800;		// divided by 4096 later
//int32_t Ki =   3;		// divided by 4096 later
//int32_t Kd =   800;		// divided by 4096 later
//void controlLoop()
//{
	//prevCNT = nowCNT;
	//nowCNT = TCD1.CNT;
	//deltaCNT = int32_t(nowCNT - prevCNT);
	//encoderCNT += deltaCNT;
	//
	////PORTD.OUT ^= PIN2_bm;
	////_delay_ms(20);
	//
	////ser_dev << prevCNT << endl;
	////ser_dev << nowCNT << endl;
	////ser_dev << deltaCNT << endl;
	////ser_dev << encoderCNT << endl;
	////ser_dev << "---" << endl;
	//
	//// CONTROL LOOP_____________________________________________________
	//prevError = nowError;
	//nowError = int32_t(encRef) - int32_t(encoderCNT);
	//deltaError = nowError - prevError;
	//proSignal = ssmul(Kp,nowError);
	//
	//intError = ssadd(intError,nowError);
	////if (deltaError == 0) Ki += 1; // SPECIAL LOGIC... Bad
	//intSignal = ssmul(Ki,intError);
//
	////if (intSignal > ssmul( 1600,256))  intSignal = ssmul( 1600,256);
	////if (intSignal < ssmul(-1600,256))  intSignal = ssmul(-1600,256);
//
	//derError = deltaCNT;
	//derSignal = ssmul(Kd,derError);
	//
	////__________________________________________________________________
    //
	//actSignal = ssdiv( ssadd( ssadd(proSignal,intSignal), derSignal), 4096);//Kp*nowError/256;//
	//if (actSignal >  1600) actSignal =  1600;
	//if (actSignal < -1600) actSignal = -1600;
	//pwm_set4(int16_t(actSignal));
//}
//uint8_t intCNT = 0;
//void printINFO()
//{   
	//ser_dev << "Error: ";
	//ser_dev << nowError << endl;
	//ser_dev << "Pro Signal: ";
	//ser_dev << proSignal/4096 << endl;
	//ser_dev << "Int Signal: ";
	//ser_dev << intSignal/4096 << endl;
	//ser_dev << "Der Signal: ";
	//ser_dev << derSignal/4096 << endl;
	//ser_dev << "Duty Cycle: ";
	//ser_dev << actSignal << endl;
	//ser_dev << "---" << endl;
//}
//void printERROR()
//{
	//ser_dev << "encoder2: "<< TCE0.CNT << endl;
	//ser_dev << "encoder3: "<< TCC1.CNT << endl;
	//ser_dev << "---" << endl;
	////ser_dev << "x: " << x << endl;
	////ser_dev << "y: " << y << endl;
//}
//
//uint16_t errortime = F_CPU/10;
//ISR (TCF0_CCB_vect) // Control Loop
//{
	//TCF0.CCB += sampletime;
	////intCNT++;
	////PORTD.OUT ^= PIN2_bm;
	////switch(intCNT)
	////{
		////case 0:
			////printINFO();
			////break;
	////}
	//if (~(TCF0.CCB % errortime)) printERROR();
	////controlLoop(); // "Where the magic happens" (T) 2018
//}


//uint16_t conv_factor = 15;// pulses per rev
//encoder1 and encoder 2
//returns coordinates of hitter in mm based on encoder count

//getCurrentPosition(unit16_t conv_factor = 15, Encoder *enc1, Encoder *enc2)
//{
	//x = enc1.encoderCNT + enc2->encoderCNT)*(1/60*2);
	//y = -enc1.encoderCNT + enc2->encoderCNT*(1/(60*2);
//
	//return;
//}

//int32_t pte1(int32_t x, int32_t y)
//{
	//return (60)*(2)*(.5*x-.5*y);
//}
//
//int32_t pte2(int32_t x, int32_t y)
//{
	//return (60)*(2)*(.5*x+.5*y);
//}

//=====================================================================================
/** The main function sets up the RTOS.  Some test tasks are created. Then the 
 *  scheduler is started up; the scheduler runs until power is turned off or there's a 
 *  reset.
 *  @return This is a real-time microcontroller program which doesn't return. Ever.
 */
shared_data<int32_t> *X_puck_vision;
shared_data<int32_t> *Y_puck_vision;

int main (void)
{
	cli();
	// Configure the system clock to use internal oscillator at 32 MHz
	config_SYSCLOCK();
	//______________________________________________________________
	//OSC_CTRL |= OSC_RC32MEN_bm; //Setup 32Mhz crystal
	//
	//while(!(OSC_STATUS & OSC_RC32MRDY_bm));
	//
	//CCP = CCP_IOREG_gc; //Trigger protection mechanism
	//CLK_CTRL = CLK_SCLKSEL_RC32M_gc; //Enable internal  32Mhz crystal
	//_______________________________________________________________
	
	// Disable the watchdog timer unless it's needed later. This is important because
	// sometimes the watchdog timer may have been left on...and it tends to stay on
	wdt_disable ();
	// Enable high - low level interrupts and enable global interrupts
	PMIC_CTRL = (1 << PMIC_HILVLEN_bp | 1 << PMIC_MEDLVLEN_bp | 1 << PMIC_LOLVLEN_bp);
	sei();
	
	//_delay_ms(10000);
	//
	//ser_dev << clrscr << "Hockey Motor Step Response (10 Hz)" << endl << endl;
	//ser_dev << "4096*KP: " << Kp << endl << "4096*KI: " << Ki << endl << "4096*KD: " << Kd << endl;
	//ser_dev << "Step Size: " << encRef << endl << endl;
	
	//encRef = -7500;
	
	//_________________________________________________________________
	//TCF0.CTRLA = (1 << TC0_CLKSEL0_bp);    // Start clock in CCA
	//TCF0.CTRLB = (1 << TC0_CCBEN_bp);		// Enable Compare Capture B
	//TCF0.INTCTRLB = (TC_CCBINTLVL_MED_gc);
	//TCF0.CCB = TCF0.CNT + sampletime;
	//_________________________________________________________________
	//PORTD.DIRSET = PIN2_bm;
	
	
	PID_Controller::PID_config_t PIDcfg1;
	PIDcfg1.Gain_divider = 4096;
	PIDcfg1.Kp = 2*3000;
	PIDcfg1.Ki = 3;
	PIDcfg1.Kd = 2*800;
	PIDcfg1.Kaw = 0;
	
	PID_Controller::PID_config_t PIDcfg2;
	PIDcfg2.Gain_divider = PIDcfg1.Gain_divider;
	PIDcfg2.Kp = PIDcfg1.Kp;
	PIDcfg2.Ki = PIDcfg1.Ki;
	PIDcfg2.Kd = PIDcfg1.Kd;
	PIDcfg2.Kaw = PIDcfg1.Kaw;
	
	_delay_ms(3000);
	
	
	X_puck_vision = new shared_data<int32_t> ();
	Y_puck_vision = new shared_data<int32_t> ();

	
	//int32_t x_goal = 150;
	//int32_t y_goal = 150;
	//mot1->set_encoderRef(pte1(pi_get[1],pi_get[0]));
	//mot2->set_encoderRef(pte2(x_goal,y_goal));
	task_vision* vis_ptr = new task_vision("VISION", task_priority(3), 256, &ser_dev, &spi_d);
	task_motor* mot1 = new task_motor("MOTOR1", task_priority(4), 256, &ser_dev, 1, PIDcfg1);
	task_motor* mot2 = new task_motor("MOTOR2", task_priority(4), 256, &ser_dev, 2, PIDcfg2);
	task_master* master_ptr = new task_master("MASTER", task_priority(3), 256, &ser_dev, mot1, mot2, vis_ptr);
	new task_IO("IO", task_priority(2), 256, &ser_dev, master_ptr, mot1, mot2, vis_ptr );
	
	
	//while(1);
	
	vTaskStartScheduler ();
	
	//while(1){}
	
	return 1; // THIS SHOULD NEVER HAPPEN
}
	
//
//

	//
	//// The user interface is at low priority; it could have been run in the idle task
	//// but it is desired to exercise the RTOS more thoroughly in this test program
	//new task_user ("UserInt", task_priority (0), 260, &ser_dev);
	//
	//// The LED blinking task is also low priority and is used to test the timing accuracy
	//// of the task transitions.
	//new task_LED ("LED BLINKER", task_priority (1), 260, &ser_dev);
	//
	
	//
	//// Here's where the RTOS scheduler is started up. It should never exit as long as
	//// power is on and the microcontroller isn't rebooted
	//vTaskStartScheduler ();
