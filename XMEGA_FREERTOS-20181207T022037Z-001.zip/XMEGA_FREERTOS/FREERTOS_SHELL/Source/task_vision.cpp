//**************************************************************************************
/** \file task_LED.cpp
 *    This file contains source code for a user interface task for a ME405/FreeRTOS
 *    test suite. 
 *
 *  Revisions:
 *    \li 09-16-2018 CTR Adapted from JRR task_user.cpp
 *    \li 09-30-2012 JRR Original file was a one-file demonstration with two tasks
 *    \li 10-05-2012 JRR Split into multiple files, one for each task
 *    \li 10-25-2012 JRR Changed to a more fully C++ version with class task_user
 *    \li 11-04-2012 JRR Modified from the data acquisition example to the test suite
 *
 *  License:
 *    This file is copyright 2012 by JR Ridgely and released under the Lesser GNU 
 *    Public License, version 2. It intended for educational use only, but its use
 *    is not limited thereto. */
/*    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */
//**************************************************************************************

#include <avr/io.h>                         // Port I/O for SFR's
#include <avr/wdt.h>                        // Watchdog timer header

#include "shared_data_sender.h"
#include "shared_data_receiver.h"
#include "task_motor.h"                      // Header for this file
#include "task_IO.h"
#include "task_master.h"
#include "task_vision.h"
#include "SPI_Slave.h"                      // SPI oh yeah!
#include "shares.h"
//-------------------------------------------------------------------------------------
/** This constructor creates a new data acquisition task. Its main job is to call the
 *  parent class's constructor which does most of the work.
 *  @param a_name A character string which will be the name of this task
 *  @param a_priority The priority at which this task will initially run (default: 0)
 *  @param a_stack_size The size of this task's stack in bytes 
 *                      (default: configMINIMAL_STACK_SIZE)
 *  @param p_ser_dev Pointer to a serial device (port, radio, SD card, etc.) which can
 *                   be used by this task to communicate (default: NULL)
 */

task_vision::task_vision (const char* a_name, 
					  unsigned portBASE_TYPE a_priority, 
					  size_t a_stack_size,
					  emstream* p_ser_dev,
					  SPI_Slave* p_spi_slave
					 )
	: frt_task (a_name, a_priority, a_stack_size, p_ser_dev)
{
	SPI_ptr = p_spi_slave;
}

//-------------------------------------------------------------------------------------
/** This task blinks an LED attached to PORTR Pin 1
 */

//int32_t etpxIO(int32_t enc1, int32_t enc2)
//{
	//int32_t conv_factor = 60;
	//return (enc1 + enc2)/(2*conv_factor);
//}
//
//int32_t etpyIO(int32_t enc1, int32_t enc2)
//{
	//int32_t conv_factor = 60;
	//return (enc2 - enc1)/(2*conv_factor);
//}

int32_t task_vision::get_x(void)
{
	return x_puck_vis;
}

int32_t task_vision::get_y(void)
{
	return y_puck_vis;
}

void task_vision::run (void)
{
	// Make a variable which will hold times to use for precise task scheduling
	portTickType previousTicks = xTaskGetTickCount ();

	// Wait a little while for user interface task to finish up
	delay_ms(10);
	while(1)
	{
		switch (state)
		{	
			//case WAIT:
				//if (see) transition_to(GET_VIS);
				//break;
			case GET_VIS:
				// ctr=0;
				SPI_ptr->send_and_receive(6,pi_send,pi_get);
				//*p_serial << PMS ("pg0: ")<< pi_get[0] << endl;
				//*p_serial << PMS ("pg1: ")<< pi_get[1] << endl;
				//*p_serial << PMS ("pg2: ")<< pi_get[2] << endl;
				//*p_serial << PMS ("pg3: ")<< pi_get[3] << endl;
				//*p_serial << PMS ("pg4: ")<< pi_get[4] << endl;
				//*p_serial << PMS ("pg5: ")<< pi_get[5] << endl;
				//*p_serial << PMS ("---") << endl;
				x_puck_vis = (int32_t(int32_t(pi_get[1])*10+int32_t(pi_get[0])-8)*16)/10;
				y_puck_vis = (int32_t(int32_t(pi_get[3])*10+int32_t(pi_get[2])-26)*16)/10;
				
				if (y_puck_vis < 0) y_puck_vis = 0;
				if (y_puck_vis > 250) y_puck_vis = 0;
				if (x_puck_vis < 0) x_puck_vis = 0;
				if (x_puck_vis > 415) x_puck_vis = 415;
				
				X_puck_vision->put(x_puck_vis);
				Y_puck_vision->put(y_puck_vis);
				
				//x_puck_vis = (int32_t(pi_get[0]*3-10)*16)/10-60; // Conversion from SPI pixel data to mm on hockey board
				//y_puck_vis = (int32_t(pi_get[1]*3-30)*16)/10-110; // Conversion from SPI pixel data to mm on hockey board
				//see = false;
				//transition_to(WAIT);
				break;
			default:
				break;
		}
		runs++;
		delay_from_to_ms(previousTicks,1);
	}
}