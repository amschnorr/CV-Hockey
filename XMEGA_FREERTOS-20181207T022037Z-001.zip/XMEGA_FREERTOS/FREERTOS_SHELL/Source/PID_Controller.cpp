//**********************************************************************************
/** \file PID_controller.cpp
 *    This file contains a highly configurable PI control algorithm.
 *
 *  \author 
 *
 *  Revisions:
 *	  \li 11-17-2017 CTR Original File
 *
 *  License:
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */
//**********************************************************************************


#include "PID_Controller.h"

//**********************************************************************************
/** \brief This constructor sets up an unconfigured 16 bit PID controller
 *  \details The PID is initialized with all gains set to 0 and no saturation limits.
 *           The pointers for actual, reference, feedforward, and feedback values
 *           are set as nullptrs by default.
 */
PID_Controller::PID_Controller()
{
	
}

//**********************************************************************************
/** \brief This constructor sets up a configured 16 bit PID controller
 *  \details The PID is initialized with a configuration as defined by the input
 *           to the constructor.
 *  @param cfg A struct containing the desired configuration parameters for the PID.
 */
PID_Controller::PID_Controller(PID_config_t cfg):cfg(cfg)
{
	
}

//**********************************************************************************
/** \brief Computes the new PID output value
 *  \details This method uses current actual and reference values to compute the controller
 *           output value. The mode and gain settings are considered during the calculation
 *  @return This function returns the new output of the PID controller after updating the state
 *          of the controller.
 */
int16_t PID_Controller::run()
{
	// exit immediately with effort = 0 if controller in off mode
	if(mode == OFF)
	{
		return 0;
	}
	
	// Compute error
	error = sssub(reference_value,actual_reading);
	
	// Compute proportional actuation signal
	Kp_signal = ssdiv(ssmul(cfg.Kp,error),cfg.Gain_divider);
	
	// Compute anti-windup signal to feed into integral control
	anti_windup_error = ssdiv(ssmul(cfg.Kaw,sssub(act_output,act_sig_pre_sat)),cfg.Gain_divider);
	
	// Combine integral and anti-windup error signals
	Ki_Kaw_error = ssadd(error,anti_windup_error);
	
	// Compute total integral actuation signal
	Ki_signal += ssdiv(ssmul(cfg.Ki,Ki_Kaw_error),cfg.Gain_divider);
	
	// Saturate integral actuation signal
	if (Ki_signal > cfg.Int_sat_max)
	{
		Ki_signal = cfg.Int_sat_max;
	}
	else if (Ki_signal < cfg.Int_sat_min)
	{
		Ki_signal = cfg.Int_sat_min;
	}
	
	// Compute derivative actuation signal
	Kd_signal = ssdiv(ssmul(sssub(error,previous_error),cfg.Kd),cfg.Gain_divider);
	
	// Store current error as previous error
	previous_error = error;
	
	// Combine actuation signals based on controller mode
	if (mode == P)
	{
		act_sig_pre_sat = Kp_signal;	
	}
	else if (mode == PI)
	{
		act_sig_pre_sat = ssadd(Kp_signal,Ki_signal);
	}
	else if (mode == PD)
	{
		act_sig_pre_sat = ssadd(Kp_signal,Kd_signal);
	}
	else if (mode == PID)
	{
		act_sig_pre_sat = ssadd(ssadd(Kp_signal,Ki_signal),Kd_signal);
	}
	else
	{
		act_sig_pre_sat = Kp_signal;	
	}
	
	// Saturate the summed actuation signal to get final output value
	if (act_sig_pre_sat >= cfg.act_sat_max)
	{
		act_output = cfg.act_sat_max;
	}
	else if (act_sig_pre_sat <= cfg.act_sat_min)
	{
		act_output = cfg.act_sat_min;
	}
	else
	{
		act_output = act_sig_pre_sat;
	}


	return int16_t(act_output);
}