//**************************************************************************************
/** \file task_LED.cpp
 *    This file contains source code for a user interface task for a ME405/FreeRTOS
 *    test suite. 
 *
 *  Revisions:
 *    \li 09-16-2018 CTR Adapted from JRR task_user.cpp
 *    \li 09-30-2012 JRR Original file was a one-file demonstration with two tasks
 *    \li 10-05-2012 JRR Split into multiple files, one for each task
 *    \li 10-25-2012 JRR Changed to a more fully C++ version with class task_user
 *    \li 11-04-2012 JRR Modified from the data acquisition example to the test suite
 *
 *  License:
 *    This file is copyright 2012 by JR Ridgely and released under the Lesser GNU 
 *    Public License, version 2. It intended for educational use only, but its use
 *    is not limited thereto. */
/*    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */
//**************************************************************************************

#include <avr/io.h>                         // Port I/O for SFR's
#include <avr/wdt.h>                        // Watchdog timer header

#include "shared_data_sender.h"
#include "shared_data_receiver.h"
#include "task_motor.h"                      // Header for this file
#include "task_IO.h"
#include "task_master.h"

//-------------------------------------------------------------------------------------
/** This constructor creates a new data acquisition task. Its main job is to call the
 *  parent class's constructor which does most of the work.
 *  @param a_name A character string which will be the name of this task
 *  @param a_priority The priority at which this task will initially run (default: 0)
 *  @param a_stack_size The size of this task's stack in bytes 
 *                      (default: configMINIMAL_STACK_SIZE)
 *  @param p_ser_dev Pointer to a serial device (port, radio, SD card, etc.) which can
 *                   be used by this task to communicate (default: NULL)
 */

task_IO::task_IO (const char* a_name, 
					  unsigned portBASE_TYPE a_priority, 
					  size_t a_stack_size,
					  emstream* p_ser_dev,
					  task_master* p_master,
					  task_motor* new_mot_ptr1,
					  task_motor* new_mot_ptr2,
					  task_vision* p_vis
					 )
	: frt_task (a_name, a_priority, a_stack_size, p_ser_dev)
{
	mot1 = new_mot_ptr1;
	mot2 = new_mot_ptr2;
	vis_ptr = p_vis;
	master = p_master;
}

//-------------------------------------------------------------------------------------
/** This task blinks an LED attached to PORTR Pin 1
 */

//int32_t etpxIO(int32_t enc1, int32_t enc2)
//{
	//int32_t conv_factor = 60;
	//return (enc1 + enc2)/(2*conv_factor);
//}
//
//int32_t etpyIO(int32_t enc1, int32_t enc2)
//{
	//int32_t conv_factor = 60;
	//return (enc2 - enc1)/(2*conv_factor);
//}

void task_IO::run (void)
{
	// Make a variable which will hold times to use for precise task scheduling
	portTickType previousTicks = xTaskGetTickCount ();

	// Wait a little while for user interface task to finish up
	delay_ms(10);

	while(1)
	{
		switch (state)
		{
			case IO_INIT:
				// ctr=0;
				//*p_serial << PMS ("enc1 CNT: ")<< (*mot1).encoderCNT << endl;
				//*p_serial << PMS ("enc2 CNT: ")<< (*mot2).encoderCNT << endl;
				*p_serial << PMS ("x_slider: ")<< (*master).x_slider << endl;
				*p_serial << PMS ("y_slider: ")<< (*master).y_slider << endl;
				*p_serial << PMS ("x_puck_vis: ")<< (X_puck_vision->get()) << endl;
				*p_serial << PMS ("y_puck_vis: ")<< (Y_puck_vision->get()) << endl;
				//*p_serial << PMS ("x_puck: ")<< (*master).get_x() << endl;
				//*p_serial << PMS ("y_puck: ")<< (*master).get_y() << endl;
				//*p_serial << PMS ("x_diff: ")<< (*master).x_diff << endl;
				//*p_serial << PMS ("y_diff: ")<< (*master).y_diff << endl;
				//*p_serial << PMS ("enc_set_1: ")<< (*master).enc_set_1 << endl;
				//*p_serial << PMS ("enc_set_2: ")<< (*master).enc_set_2 << endl;
				//*p_serial << PMS ("Error 1: ")<< (*mot1).mot_controller.error << endl;
				//*p_serial << PMS ("Error 2: ")<< (*mot2).mot_controller.error << endl;
				//*p_serial << PMS ("Actuation Signal 1: ")<< (*mot1).mot_controller.act_sig_pre_sat << endl;
				//*p_serial << PMS ("Actuation Signal 2: ")<< (*mot2).mot_controller.act_sig_pre_sat << endl;
				//*p_serial << PMS ("duty1: ")<< (*mot1).pwm_input << endl;
				//*p_serial << PMS ("duty2: ")<< (*mot2).pwm_input << endl;
				//*p_serial << PMS ("PID 1: ")<< (*mot1).mot_controller.cfg.Kp << " ";
				//*p_serial                   << (*mot1).mot_controller.cfg.Ki << " ";
				//*p_serial                   << (*mot1).mot_controller.cfg.Kd << endl;
				//*p_serial << PMS ("PID 2: ")<< (*mot2).mot_controller.cfg.Kp << " ";
				//*p_serial                   << (*mot2).mot_controller.cfg.Ki << " ";
				//*p_serial                   << (*mot2).mot_controller.cfg.Kd << endl;
				*p_serial << PMS ("---") << endl;
				break;
		
			default:
				break;
		}
		runs++;
		delay_from_to_ms(previousTicks,50);
	}
}