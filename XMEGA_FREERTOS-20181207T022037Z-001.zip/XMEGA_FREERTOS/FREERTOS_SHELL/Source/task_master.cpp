//**************************************************************************************
/** \file task_LED.cpp
 *    This file contains source code for a user interface task for a ME405/FreeRTOS
 *    test suite. 
 *
 *  Revisions:
 *    \li 09-16-2018 CTR Adapted from JRR task_user.cpp
 *    \li 09-30-2012 JRR Original file was a one-file demonstration with two tasks
 *    \li 10-05-2012 JRR Split into multiple files, one for each task
 *    \li 10-25-2012 JRR Changed to a more fully C++ version with class task_user
 *    \li 11-04-2012 JRR Modified from the data acquisition example to the test suite
 *
 *  License:
 *    This file is copyright 2012 by JR Ridgely and released under the Lesser GNU 
 *    Public License, version 2. It intended for educational use only, but its use
 *    is not limited thereto. */
/*    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */
//**************************************************************************************

#include <avr/io.h>                         // Port I/O for SFR's
#include <avr/wdt.h>                        // Watchdog timer header

#include "shared_data_sender.h"
#include "shared_data_receiver.h"
#include "task_motor.h"                      // Header for this file
#include "task_master.h"
#include "SPI_Slave.h"                      // SPI oh yeah!
#include "task_vision.h"
#include "shares.h"

//-------------------------------------------------------------------------------------
/** This constructor creates a new data acquisition task. Its main job is to call the
 *  parent class's constructor which does most of the work.
 *  @param a_name A character string which will be the name of this task
 *  @param a_priority The priority at which this task will initially run (default: 0)
 *  @param a_stack_size The size of this task's stack in bytes 
 *                      (default: configMINIMAL_STACK_SIZE)
 *  @param p_ser_dev Pointer to a serial device (port, radio, SD card, etc.) which can
 *                   be used by this task to communicate (default: NULL)
 */

task_master::task_master (const char* a_name, 
					  unsigned portBASE_TYPE a_priority, 
					  size_t a_stack_size,
					  emstream* p_ser_dev,
					  task_motor* new_mot_ptr1,
					  task_motor* new_mot_ptr2,
					  task_vision* p_vis
					 )
	: frt_task (a_name, a_priority, a_stack_size, p_ser_dev)
{
	mot1 = new_mot_ptr1;
	mot2 = new_mot_ptr2;
	vis_ptr = p_vis;
}

//-------------------------------------------------------------------------------------
/** This task blinks an LED attached to PORTR Pin 1
 */

int32_t etpx(int32_t enc1, int32_t enc2)
{
	int32_t conv_factor = 60;
	return (enc1 + enc2)/(2*conv_factor);
}

int32_t etpy(int32_t enc1, int32_t enc2)
{
	int32_t conv_factor = 60;
	return (enc1 - enc2)/(2*conv_factor);
}



//uint32_t x_diff;
//uint32_t y_diff;

int32_t pte1(int32_t x, int32_t y)
{
	return 60*(x+y);
}

int32_t pte2(int32_t x, int32_t y)
{
	return 60*(x-y);
}

int32_t task_master::get_x(void)
{
	return x_puck;
}

int32_t task_master::get_y(void)
{
	return y_puck;
}

void task_master::run (void)
{
	// Make a variable which will hold times to use for precise task scheduling
	portTickType previousTicks = xTaskGetTickCount ();

	// Wait a little while for user interface task to finish up
	int8_t n;
	uint8_t buff_ctr = 0;
	delay_ms(10);

	while(1)
	{
		switch (state)
		{	
			//case REQUEST_PUCK:
				//vis_ptr->see = true;
				//transition_to(MASTER_LOOP);
				//break;
			//case JOG1:
				//x_puck = 254;
				//y_puck = 0;
				//enc_set_1 = pte1(x_puck,y_puck);
				//enc_set_2 = pte2(x_puck,y_puck);
				//mot1->set_encoderRef(enc_set_1);
				//mot2->set_encoderRef(enc_set_2);
				//x_slider = etpx((*mot1).encoderCNT, (*mot2).encoderCNT); // X position of the slider converting from encoder ticks
				//y_slider = etpy((*mot1).encoderCNT, (*mot2).encoderCNT); // Y position of the slider converting from encoder ticks
				//transition_to(JOG2);
				//break;
			//case JOG2:
				//x_puck = 254;
				//y_puck = -254;
				//enc_set_1 = pte1(x_puck,y_puck);
				//enc_set_2 = pte2(x_puck,y_puck);
				//mot1->set_encoderRef(enc_set_1);
				//mot2->set_encoderRef(enc_set_2);
				//x_slider = etpx((*mot1).encoderCNT, (*mot2).encoderCNT); // X position of the slider converting from encoder ticks
				//y_slider = etpy((*mot1).encoderCNT, (*mot2).encoderCNT); // Y position of the slider converting from encoder ticks
				//transition_to(JOG4);
				//break;
			//case JOG3:
				//x_puck = 0;
				//y_puck = -254;
				//enc_set_1 = pte1(x_puck,y_puck);
				//enc_set_2 = pte2(x_puck,y_puck);
				//mot1->set_encoderRef(enc_set_1);
				//mot2->set_encoderRef(enc_set_2);
				//x_slider = etpx((*mot1).encoderCNT, (*mot2).encoderCNT); // X position of the slider converting from encoder ticks
				//y_slider = etpy((*mot1).encoderCNT, (*mot2).encoderCNT); // Y position of the slider converting from encoder ticks
				//transition_to(JOG1);
				//break;
			//case JOG4:
				//x_puck = 0;
				//y_puck = 0;
				//enc_set_1 = pte1(x_puck,y_puck);
				//enc_set_2 = pte2(x_puck,y_puck);
				//mot1->set_encoderRef(enc_set_1);
				//mot2->set_encoderRef(enc_set_2);
				//x_slider = etpx((*mot1).encoderCNT, (*mot2).encoderCNT); // X position of the slider converting from encoder ticks
				//y_slider = etpy((*mot1).encoderCNT, (*mot2).encoderCNT); // Y position of the slider converting from encoder ticks
				//transition_to(JOG3);
				//break;
			case MASTER_LOOP:
				// ctr=0;
				//SPI_ptr->send_and_receive(4,pi_send,pi_get);
				//ser_dev << "SPI SAYS: " << "x= " << pi_get[1] << ","<< "y= " << pi_get[0]<< endl;
				
				//x_puck = (int32_t(pi_get[0])*16)/10; // Conversion from SPI pixel data to mm on hockey board
				//y_puck = (int32_t(pi_get[1])*16)/10; // Conversion from SPI pixel data to mm on hockey board

				//x_puck = vis_ptr->get_x();
				//y_puck = vis_ptr->get_y();
				
				//x_puck = X_puck_vision->get();
				//y_puck = Y_puck_vision->get();
				
				
				x_puck_buff[buff_ctr] = X_puck_vision->get();
				y_puck_buff[buff_ctr] = Y_puck_vision->get();
				x_puck_sum = 0;
				y_puck_sum = 0;
				for ( n = 0; n < 10; n++)
				{
					x_puck_sum += x_puck_buff[n];
					y_puck_sum += y_puck_buff[n];
				}
				x_puck = x_puck_sum/10;
				y_puck = y_puck_sum/10;
				buff_ctr++;
				if (buff_ctr > 9) buff_ctr = 0;
				
				//
				//if (y_puck < 0) y_puck = 0;
				//if (y_puck > 210) y_puck = 210;
				//if (x_puck < 0) x_puck = 0;
				//if (x_puck > 415) x_puck = 415;
				//
				
				x_slider = etpx((*mot1).encoderCNT, (*mot2).encoderCNT); // X position of the slider converting from encoder ticks
				y_slider = etpy((*mot1).encoderCNT, (*mot2).encoderCNT); // Y position of the slider converting from encoder ticks
				//
				//x_diff = x_puck - x_slider; // X position difference from puck to slider
				//y_diff = y_puck - y_slider; // Y position difference from puck to slider
				
				//enc_diff_1 = -1*pte1(x_diff,y_diff);
				//enc_diff_2 = -1*pte2(x_diff,y_diff);
				
				enc_set_1 = pte1(x_puck,y_puck);
				enc_set_2 = pte2(x_puck,y_puck);
				
				//mot1->encoderRef = enc_diff_1;
				//mot2->encoderRef = enc_diff_2;
				
				mot1->set_encoderRef(enc_set_1);
				mot2->set_encoderRef(enc_set_2);
				mot1->update = true;
				mot2->update = true;
				//vis_ptr->see = false;
				//transition_to(REQUEST_PUCK);

				break;
		
			default:
				break;
		}
		
		runs++;
		delay_from_to_ms(previousTicks,10);
	}
}