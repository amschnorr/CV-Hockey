//**********************************************************************************
/** \file PID_controller.h
 *    This file contains a highly configurable PI control algorithm.
 *
 *  \author Charlie Refvem
 *
 *  Revisions:
 *	  \li 11-17-2017 CTR Original File
 *
 *  License:
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUEN-
 *    TIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *    OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */


// This define prevents this .h file from being included multiple times in a .CPP file
#ifndef PID_CONTROLLER_H_
#define PID_CONTROLLER_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include "satmath.h"

//**********************************************************************************
/** \brief This class defines and runs a 16-bit fixed point PID controller
 */
class PID_Controller
{
	public:
	/** \brief This enumeration defines possible modes of operation for the PID controller.
	 */
	typedef enum PID_MODE {
		OFF					= 1,						//!< Controller is disabled
		MANUAL				= 2,						//!< Controller is in manual mode
		P					= 3,						//!< P mode only
		PI					= 4,						//!< PI mode only
		IP					= 5							//!< IP mode only
	} PID_MODE_t;

	/** \brief this struct defines a pid configuration that contains all the tuning parameters for
	 */
	typedef struct PID_config {
		int16_t				Kp = 0;						//!< Proportional gain
		int16_t				Ti = 0;						//!< Integral Time Constant
		int16_t				Ki = 0;						//!< Integral Gain
		int16_t				Td = 0;						//!< Derivative Time Constant
		int16_t				Kd = 0;						//!< Derivative Gain
		int16_t				Kw = 0;						//!< Anti-Windup Gain
		int16_t				Ka = 0;						//!< Amplifier Gain
		int16_t				Kff = 0;					//!< Feed-forward gain
		int16_t				Kfb = 0;					//!< Feed-back gain
		int16_t				sat_max = INT16_MAX;		//!< Saturater Maximal Output
		int16_t				sat_min = INT16_MIN;		//!< Saturater Maximal Output
	} PID_config_t;
	
	// Constructors
	PID_Controller();									//!< PID Default constructor
	PID_Controller(PID_config_t cfg);					//!< Configuration Constructor
	
	// Methods
	int16_t					run();						//!< Method for running the control loop one iteration
	
	// Attributes
	PID_MODE_t				mode = OFF;					//!< PID Mode enumeration
	PID_config_t			cfg;						//!< PID configuration struct
	int16_t					reference=0;				//!< Pointer to Set point for controller
	int16_t					actual=0;					//!< Pointer to actual or measured value being controlled
	int16_t					feedforward=0;				//!< Pointer to reference for feed-forward actuation
	int16_t					feedback=0;					//!< Pointer to reference for feed-back actuation
	
	protected:
	int32_t					esum=0;						//!< Integrator for I controller
	int16_t					error=0;					//!< Error between reference and actual values
	int16_t					a_p=0;						//!< Proportional actuation value
	int16_t					a_i=0;						//!< Integral actuation value
	int16_t					a_ff=0;						//!< Feed-forward actuation value
	int16_t					a_fb=0;						//!< Feed-back actuation value
	int16_t					a_desired=0;				//!< Desired actuation value
	int16_t					a_requested=0;				//!< Requested actuation value
	int16_t					a_output=0;					//!< Value output from controller after amplifier gain
	
	private:
};


#endif /* PID_CONTROLLER_H_ */